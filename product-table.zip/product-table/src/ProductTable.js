// src/ProductTable.js
import React, { useState, useEffect } from 'react';
import { getProducts } from './api';

const ProductTable = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      const data = await getProducts();
      setProducts(data);
    };
    fetchProducts();
  }, []);

  return (
    <table>
      <thead>
        <tr>
          <th>Product Name</th>
          <th>Description</th>
          <th>Image</th>
        </tr>
      </thead>
      <tbody>
        {products.map((product) => (
          <tr key={product.id}>
            <td>{product.title}</td>
            <td>{product.description}</td>
            <td>
              <img src={product.images[0]} alt={product.title} />
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ProductTable;